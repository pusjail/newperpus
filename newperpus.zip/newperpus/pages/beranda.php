<div>
	<h3>Beranda</h3>
</div>

<div class="card border-0 shadow">
	<div class="card-body text-center">
		<h1 class=" font-weight-bold mb-5">SELAMAT DATANG DI SISTEM INFORMASI PERPUSTAKAAN <br>Universitas Indraprasta PGRI</h1>
		<h2>"MEMBACA ADALAH JENDELA DUNIA"</h2>
		<p>"Arahkanlah perhatianmu kepada didikan, dan telingamu kepada kata-kata pengetahuan.
			Hai anakku, jika hatimu bijak, hatiku juga bersukacita.
			Jiwaku bersukaria, kalau bibirmu mengatakan yang jujur.
			Belilah kebenaran dan jangan menjualnya; demikian juga dengan hikmat, didikan dan pengertian."</p>
	</div>
</div>